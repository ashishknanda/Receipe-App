package com.ashish.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class postadapter extends RecyclerView.Adapter<postadapter.MyViewHolder>{
    private Context context;
    private List<PostModel> postModels;

    public postadapter(Context context, List<PostModel> postModels) {
        this.context = context;
        this.postModels = postModels;
    }

    @NonNull
    @Override
    public postadapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v;
        v = LayoutInflater.from(context).inflate(R.layout.row_post,viewGroup,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull postadapter.MyViewHolder myViewHolder, int i){
        myViewHolder.title.setText(postModels.get(i).getStrCategory());
        Picasso.get().load(postModels.get(i).getStrCategoryThumb()).into(myViewHolder.profile);
    }

    @Override
    public int getItemCount() {

        return postModels.size();
    }
    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView title;
        ImageView profile;
        View v;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            v=itemView;
            title = v.findViewById(R.id.titleofpost);
            profile = v.findViewById(R.id.profilepic);

        }
    }
}
