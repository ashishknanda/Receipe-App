package com.ashish.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeActivity extends AppCompatActivity {
    private RecyclerView rec;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        GetDataService service = RetrofitInstance.getInstance().create(GetDataService.class);
        Call<List<PostModel>> call = service.getAllData();

        call.enqueue(new Callback<List<PostModel>>() {
            @Override
            public void onResponse(Call<List<PostModel>> call, Response<List<PostModel>> response) {
                setalldata(response.body());

            }

            @Override
            public void onFailure(Call<List<PostModel>> call, Throwable t) {
                Toast.makeText(HomeActivity.this, "Failed To Retrieve Data!", Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void setalldata(List<PostModel> data) {
        rec = findViewById(R.id.recyler);
        rec.setLayoutManager(new LinearLayoutManager(this));
        postadapter mpostadapter = new postadapter(getApplicationContext(),data);
        rec.setAdapter(mpostadapter);
        mpostadapter.notifyDataSetChanged();
    }
}
