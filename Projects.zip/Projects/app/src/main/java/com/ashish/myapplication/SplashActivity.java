package com.ashish.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        Handler handler=new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(SplashActivity.this, "Welcome to Receipe App", Toast.LENGTH_SHORT).show();
                Intent i=new Intent(SplashActivity.this,HomeActivity.class);
                startActivity(i);
                finish();
            }
        },2000);
    }
}
